package org.me.gcu.equakestartercode;

import java.util.ArrayList;

public class ArrayStore {
    public static ArrayList<String> storeTitles = new ArrayList<String>();
    public static ArrayList<String> storeDescription = new ArrayList<String>();
    public static ArrayList<String> storeLink = new ArrayList<String>();
    public static ArrayList<String> storePubDate = new ArrayList<String>();
    public static ArrayList<String> storeCategory = new ArrayList<String>();
    public static ArrayList<String> storeGeoLat = new ArrayList<String>();
    public static ArrayList<String> storeGeoLong = new ArrayList<String>();
    public static ArrayList<Float> storeMag = new ArrayList<Float>();
    public static ArrayList<String> displayText = new ArrayList<String>();
}
